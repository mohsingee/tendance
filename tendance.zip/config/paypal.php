<?php
return [
    'client_id' => 'AUiR_CMBbI6Ks2Sbo_3VyFWICdyBTGW0GhKT0BXJIykp6k6cgMkoKIfMhZQL541KyO1vCPjrz7sgRuaO',
    'secret' => 'EJpyjBnxKpSa0IbVOw14PKpTDvv6EipSH4vqxGnMV4O6ifkjBpaJYBBVCw9S8h52e9pPODM6hCbgoyBa',
    'settings' => array(
        'mode' => 'sandbox',
        'http.ConnectionTimeOut' => 1000,
        'log.LogEnabled' => true,
        'log.FileName' => storage_path() . '/logs/paypal.log',
        'log.LogLevel' => 'FINE'
    ),
];
